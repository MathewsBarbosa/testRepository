﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If ColorDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then

            Dim rValue, gValue, bValue
            rValue = ColorDialog1.Color.R
            gValue = ColorDialog1.Color.G
            bValue = ColorDialog1.Color.B

            Debug.Print(rValue & " " & gValue & " " & bValue)

            Dim CATIA As Object
            CATIA = GetObject(, "CATIA.Application")
            If CATIA Is Nothing Then
                CATIA = CreateObject("CATIA.Application")
                CATIA.Visible = True
            End If
            Dim sc, vsc
            sc = CATIA.SettingControllers
            vsc = sc.Item("CATVizVisualizationSettingCtrl")

            vsc.SetBackgroundRGB(rValue, gValue, bValue)
            vsc.SaveRepository()

        End If
        Me.Close()
    End Sub

End Class
