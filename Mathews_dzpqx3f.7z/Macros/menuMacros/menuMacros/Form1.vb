﻿'Develped by:   Mathews Barbosa
'Date:          24-03-2017
'Department:    VW_AE_UNCC_CAD
'Description:   Cria uma lista de botões para as respetivas macros situadas
'               na pasta objStartFolder

Public Class Form1

    Dim objStartFolder
    Dim arr As New Collection()

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.CenterToScreen()

        Dim objFSO, objFolder, colfiles

        objFSO = CreateObject("Scripting.FileSystemObject")

        objStartFolder = "O:\070_Users\Mathews_dzpqx3f\Macros\"

        objFolder = objFSO.GetFolder(objStartFolder)

        'lista de ficheiros
        colfiles = objFolder.Files

        'Para cada ficheiro 
        'na lista de ficheiros
        'adiciona a uma array
        'todos os ficheiros do tipo
        '.catvbs

        For Each f In colfiles
            Dim tmp
            tmp = Split(f.Name, ".")

            If tmp(1).Equals("catvbs") Then
                arr.Add(f.Name)
            End If
        Next

        'Preenche a form com buttons com a
        'array anterior

        For i = 1 To arr.Count
            Dim b As New Button
            b.Name = "Button" & i
            b.Text = arr.Item(i)
            b.Location = New Point(20, i * 30)
            b.Size = New Size(300, 30)
            b.Font = New Font("Microsoft Sans Serif", 10)
            Me.Controls.Add(b)
            AddHandler b.Click, AddressOf Me.Button_Click
        Next

    End Sub

    Private Sub Button_Click(sender As Object, e As EventArgs)
        'executa a array

        'Guarda o nome da macro
        Dim tmp
        tmp = Split(sender.ToString, ":")

        Dim returnValue As Long
        returnValue = 0

        'Guarda a posição da macro
        For Each n In arr
            returnValue = returnValue + 1
            If n = Trim(tmp(1)) Then
                Exit For
            End If
        Next

        'Retorna a posição da macro para ser
        'executada num ficheiro catvbs
        Environment.ExitCode = returnValue
        Me.Close()

    End Sub

End Class
