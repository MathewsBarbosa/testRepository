/* 
    Prototype
*/ 
String.prototype.endsWith = function(suffix) {
    return this.indexOf(suffix, this.length - suffix.length) !== -1;
};

String.prototype.Left = function(str, n) {
    if (n <= 0)
        return "";
    else if (n > String(str).length)
        return str;
    else
        return String(str).substring(0, n);
};

String.prototype.Right = function(str, n) {
    if (n <= 0)
        return "";
    else if (n > String(str).length)
        return str;
    else {
        var iLen = String(str).length;
        return String(str).substring(iLen, iLen - n);
    }
};


Date.prototype.getWeek = function() {
    var onejan = new Date(this.getFullYear(), 0, 1);
    return Math.ceil((((this - onejan) / 86400000) + onejan.getDay() + 1) / 7);
};


/* 
    Abre o �ltimo ficheiro do relat�rio de turno    
*/ 

var pathA = 'X:\\REPTRIM\\Relatorio Turno\\EOS & Scirocco & NF\\Turno A';
var pathB = 'X:\\REPTRIM\\Relatorio Turno\\EOS & Scirocco & NF\\Turno B';

var fso = new ActiveXObject("Scripting.FileSystemObject");


function AddFiles(folderName, fileArray) {
    var f = fso.GetFolder(folderName);
    var fileEnum = new Enumerator(f.Files);
    var x = 0;
    
    for (i = 0; !fileEnum.atEnd(); fileEnum.moveNext()) {
        if (fileEnum.item().Name.endsWith("pdf") || fileEnum.item().Name.endsWith("xls")) {

            var dt = new Date(fileEnum.item().DateCreated);
            var year = dt.getFullYear().toString()
            var month = new String().Right(('0' + (dt.getMonth() + 1)), 2)
            var day = new String().Right('0' + dt.getDate().toString(), 2);
            var hour = new String().Right('0' + dt.getHours().toString(),2);
            var min = new String().Right('0' + dt.getMinutes().toString(),2);
            
            var strFileDate = year + month + day + hour + min;

            fileArray[x] = strFileDate + ';' + fileEnum.item().Path;
            x = fileArray.length;
        }
      }
}

function GetShiftReportFile() {
    var shiftReportfileList = new Array();
    AddFiles(pathA, shiftReportfileList);
    AddFiles(pathB, shiftReportfileList);

    shiftReportfileList.sort();
    var fileName = shiftReportfileList[shiftReportfileList.length-1].split(';')[1];

    var ptr = window.open('file:///' + fileName);
    if (ptr) ptr.focus();
    return false;

    fso = null;
}


function GetLastFile(folderPath) {
    var fileList = new Array();
    AddFiles(folderPath, fileList);

    fileList.sort();
    var fileName = fileList[fileList.length-1].split(';')[1];

    var ptr = window.open('file:///' + fileName);
    if (ptr) ptr.focus();
    return false;
    
    fso = null;
}


/* 
    Verifica se o ficheiro existe ou n�o, abrindo o ficheiro ou mostrando uma mensagem de erro
*/ 

function openFile(fileName) {
    var fso = new ActiveXObject("Scripting.FileSystemObject");

    if (fso.FileExists(fileName) || fso.FolderExists(fileName)) {
        var ptr = window.open('file:///' + fileName);
        if (ptr) ptr.focus();
        return false;
    }
    else
        alert('O ficheiro ou pasta "' + fileName + '" n�o est� dispon�vel ou n�o tem acesso de leitura ao mesmo.');

    fso = null;
}