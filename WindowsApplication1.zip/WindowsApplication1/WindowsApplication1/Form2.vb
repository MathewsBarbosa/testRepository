﻿Public Class Form2

    Dim t1, t2 As New toy2
    Dim bArr As New Collection()

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Valores iniciais

        Timer1.Enabled = True

        t1.toyValuesConstructer(0.3, 0.8, 10, 0.1, 10, 0.1, 10, 250)
        t1.toyBodyConstructer(Color.Black, 12, 12)
        t1.toyKeysConstructer(Keys.A, Keys.D, Keys.W)
        Me.Controls.Add(t1.pt)
        t2.toyValuesConstructer(0.3, 0.8, 10, 0.1, 10, 0.1, 10, 250)
        t2.toyBodyConstructer(Color.CadetBlue, 20, 100)
        t2.toyKeysConstructer(Keys.Left, Keys.Right, Keys.Up)
        Me.Controls.Add(t2.pt)

    End Sub

    Private Sub Form2_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        For i = 0 To Me.Controls.Count - 1
            If InStr(Me.Controls.Item(i).Controls.Owner.ToString, "Button") Then
                bArr.Add(Me.Controls.Item(i))
            End If
        Next
    End Sub

    Private Sub Form2_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown

        t1.PressKey(e)
        t2.PressKey(e)

    End Sub

    Private Sub Form2_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp

        t1.ReleaseKey(e)
        t2.ReleaseKey(e)

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Atualiza por milesegundo

        'For i = 1 To bArr.Count
        '    If t1.Collision(bArr.Item(i)) Then
        '        Exit For
        '    End If
        'Next

        'For i = 1 To bArr.Count
        '    If t2.Collision(bArr.Item(i)) Then
        '        Exit For
        '    End If
        'Next

        t1.Update()
        t2.Update()

        t1.test(Me.Controls)
        't1.CollisionBetweenPlayers(t2.pt)
        't2.CollisionBetweenPlayers(t1.pt)

    End Sub

End Class

Public Class toy2
    Dim gravity, jumpSpeed, gravityMaxAccel, gravityAccel, jumpAccel, gravityResetVal, jumpSpeedResetVal As Double
    Dim goRight, goLeft, jump, onPlat, lockL, lockR As Boolean
    Dim varHeight As Integer
    Dim kLeft, kRight, kJump As Keys
    Dim onGround, doubleJump As Boolean
    Public pt 'lb

    Sub toyValuesConstructer(gA As Double, jA As Double, gMA As Double, gRV As Double, jSRV As Double, g As Double, j As Double, vH As Integer)

        gravityAccel = gA
        jumpAccel = jA
        gravityMaxAccel = gMA
        gravityResetVal = gRV
        jumpSpeedResetVal = jSRV
        gravity = g
        jumpSpeed = j
        varHeight = vH

    End Sub

    Sub toyBodyConstructer(toyBGColor As Color, l1 As Integer, l2 As Integer)

        'lb = New System.Windows.Forms.Label()
        'lb.AutoSize = True
        'lb.BackColor = toyBGColor
        'lb.ForeColor = toyFaceColor
        'lb.Location = New System.Drawing.Point(l1, l2)
        'lb.Name = "Label1"
        'lb.Size = New System.Drawing.Size(18, 13)
        'lb.TabIndex = 0
        'lb.Text = "*-*"

        pt = New System.Windows.Forms.PictureBox
        pt.BackColor = toyBGColor
        pt.Location = New System.Drawing.Point(l1, l2)
        pt.Name = "PictureBox1"
        pt.Size = New System.Drawing.Size(18, 13)
        pt.TabIndex = 0
        pt.TabStop = False

    End Sub

    Sub toyKeysConstructer(kL As Keys, kR As Keys, kJ As Keys)

        kLeft = kL
        kRight = kR
        kJump = kJ

    End Sub

    Sub PressKey(e As KeyEventArgs)

        If lockR = False Then
            If e.KeyCode = kRight Then
                goRight = True
                goLeft = False
            End If
        End If

        If lockL = False Then
            If e.KeyCode = kLeft Then
                goLeft = True
                goRight = False
            End If
        End If

        If onGround Then
            doubleJump = True
            If e.KeyCode = kJump Then
                jump = True
            End If
        ElseIf doubleJump Then
            doubleJump = False
            If e.KeyCode = kJump Then
                jump = True
            End If
        End If

    End Sub

    Sub ReleaseKey(e As KeyEventArgs)
        If e.KeyCode = kRight Then
            goRight = False
        End If

        If e.KeyCode = kLeft Then
            goLeft = False
        End If
    End Sub

    Sub test(lst As Form2.ControlCollection)
        Dim Collision As Boolean
        Dim tmp As Integer
        For Each PictureBox In lst
            If PictureBox IsNot pt AndAlso pt.Bounds.IntersectsWith(PictureBox.Bounds) Then
                Collision = True
                tmp = PictureBox.top - PictureBox.size.height
                Exit For
            End If
        Next
        If Collision Then
            varHeight = tmp
        Else
            varHeight = 250
        End If
    End Sub

    Function Collision(b As Button) As Boolean
        If pt.Location.X > b.Location.X - 15 And _
            pt.Location.X < b.Location.X + b.Size.Width And _
            pt.Location.Y < b.Location.Y Then
            'Debug.Print(Label1.Location.X)
            varHeight = b.Top - 13
            Collision = True
            onGround = True
        Else
            varHeight = 250
            Collision = False
        End If

    End Function

    'testing out
    Sub CollisionBetweenPlayers(other As PictureBox)

        If pt.location.x > other.Location.X - 20 And pt.location.x < other.Location.X + 20 Then
            If pt.location.y > other.Location.Y + 10 And pt.location.y < other.Location.Y - 10 Then

                If goLeft Then
                    lockL = True
                    goLeft = False
                End If

                If goRight Then
                    lockR = True
                    goRight = False
                End If

            End If
        Else
            lockL = False
            lockR = False
        End If

    End Sub

    Sub Update()
        If pt.Top < varHeight Then
            If Not jump Then
                pt.Top = pt.Top + gravity
                If gravity < gravityMaxAccel Then
                    gravity = gravity + gravityAccel
                    'Debug.Print(gravity)
                End If
            End If
            onGround = False
        Else
            gravity = gravityResetVal
            pt.Top = varHeight
            onGround = True
        End If


        If jump Then
            pt.Top = pt.Top - jumpSpeed
            If jumpSpeed > 0 Then
                jumpSpeed = jumpSpeed - jumpAccel
                'Debug.Print(jumpSpeed)
            Else
                jump = False
                jumpSpeed = jumpSpeedResetVal
            End If
        End If

        If goRight Then pt.Left = pt.Left + 5

        If goLeft Then pt.Left = pt.Left - 5
    End Sub

End Class