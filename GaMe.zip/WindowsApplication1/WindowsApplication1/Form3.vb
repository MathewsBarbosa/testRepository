﻿

Public Class Form3
    Dim t1, t2 As New raceCar
    Dim bArr As New Collection()
    Dim tmp As Boolean
    'CONSTRUCTOR
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Valores iniciais

        t1.toyValuesConstructer(300)
        t1.toyBodyConstructer(Color.Black, Color.Red, 12, 100)
        t1.toyKeysConstructer(Keys.W, Keys.S, Keys.D, Keys.A)
        Me.Controls.Add(t1.lb)
        t2.toyValuesConstructer(300)
        t2.toyBodyConstructer(Color.Pink, Color.Blue, 12, 130)
        t2.toyKeysConstructer(Keys.Up, Keys.Down, Keys.Right, Keys.Left)
        Me.Controls.Add(t2.lb)

    End Sub

    'GET OBJECTS LIST
    Private Sub Form1_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        For i = 0 To Me.Controls.Count - 1
            If InStr(Me.Controls.Item(i).Name, "PictureBox") Then '<> 0 Or InStr(Me.Controls.Item(i).Controls.Owner.ToString, "Label") <> 0 Then
                bArr.Add(Me.Controls.Item(i))
            End If
        Next
    End Sub

    'KEY EVENTS
    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown

        t1.PressKey(e)
        t2.PressKey(e)

    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp

        t1.ReleaseKey(e)
        t2.ReleaseKey(e)

    End Sub

    ' UPDATE 
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Atualiza por milesegundo

        For i = 1 To bArr.Count
            If bArr.Item(i).top + bArr.Item(i).size.height >= 300 Then
                tmp = False
            ElseIf bArr.Item(i).top <= -10 Then
                tmp = True
            End If

            If tmp Then
                bArr.Item(i).top = bArr.Item(i).top + 2
            Else
                bArr.Item(i).top = bArr.Item(i).top - 2
            End If
        Next

        For i = 1 To bArr.Count
            If t1.Collision(bArr.Item(i)) Then
                Exit For
            End If
        Next

        For i = 1 To bArr.Count
            If t2.Collision(bArr.Item(i)) Then
                Exit For
            End If
        Next
        'Dim tmpObj As Object

        t1.Update()
        t2.Update()

    End Sub

End Class

'CLASS TOY AKA PLAYER

Public Class raceCar
    Dim goRight, goLeft, goUp, goDown As Boolean
    Dim varHeight, lc1, lc2 As Integer
    Dim xSpeed, ySpeed As Double
    Dim kLeft, kRight, kUp, kDown As Keys
    Dim onGround, doubleJump, isPushing As Boolean
    Public lb

    Sub toyValuesConstructer(vH As Integer)

        varHeight = vH

    End Sub

    Sub toyBodyConstructer(toyBGColor As Color, toyFaceColor As Color, l1 As Integer, l2 As Integer)

        lb = New System.Windows.Forms.Label()
        lb.AutoSize = True
        lb.BackColor = toyBGColor
        lb.ForeColor = toyFaceColor
        lc1 = l1
        lc2 = l2
        lb.Location = New System.Drawing.Point(l1, l2)
        lb.Name = "Label1"
        lb.Size = New System.Drawing.Size(18, 13)
        lb.TabIndex = 0
        lb.Text = "*-*"

    End Sub

    Sub toyKeysConstructer(kL As Keys, kR As Keys, kJ As Keys, kP As Keys)

        kLeft = kL
        kRight = kR
        kUp = kJ
        kDown = kP

    End Sub

    Sub PressKey(e As KeyEventArgs)

        If e.KeyCode = kRight Then
            goRight = True
            goLeft = False
        End If

        If e.KeyCode = kLeft Then
            goLeft = True
            goRight = False
        End If

        If e.KeyCode = kUp Then
            goUp = True
            goDown = False
        End If

        If e.KeyCode = kDown Then
            goDown = True
            goUp = False
        End If

    End Sub

    Sub ReleaseKey(e As KeyEventArgs)
        If e.KeyCode = kRight Then
            goRight = False
        End If

        If e.KeyCode = kLeft Then
            goLeft = False
        End If

        If e.KeyCode = kUp Then
            goUp = False
        End If

        If e.KeyCode = kDown Then
            goDown = False
        End If

    End Sub

    Sub finish(pb As Object)
        If lb.Bounds.IntersectsWith(pb.bounds) Then
            Debug.Print("HEHE")
        End If
    End Sub

    Function Collision(pb As Object)

        If lb.Bounds.IntersectsWith(pb.bounds) Then
            dieToy()
            Collision = True
        End If

        'If ((lb.location.x + lb.size.width) >= pb.location.x And lb.location.x <= (pb.location.x + pb.size.width)) And ((lb.location.y - lb.size.height) <= pb.location.y And lb.location.y >= (pb.location.y - pb.size.height)) Then
        '    'varHeight = pb.Top - 13
        '    Collision = True
        '    'onGround = True
        '    'If InStr(pb.ToString, "Label") <> 0 Then
        '    Debug.Print("grunt")
        '    dieToy()
        '    'End If
        'Else
        '    'varHeight = 300
        '    Collision = False
        'End If

    End Function

    'testing out
    'Function CollisionBetweenPlayers(other As Label)

    '    If lb.location.x > other.Location.X - 20 And lb.location.x < other.Location.X + 20 And lb.location.y > other.Location.Y - 10 And lb.location.y < other.Location.Y + 10 Then

    '        If goLeft Then
    '            lockL = True
    '            goLeft = False
    '            lb.Left = other.Location.X + 18
    '        End If

    '        If goRight Then
    '            lockR = True
    '            goRight = False
    '            lb.Left = other.Location.X - 18
    '        End If
    '        Return True

    '    Else
    '        lockL = False
    '        lockR = False
    '        Return False
    '    End If

    'End Function

    'Sub Update()
    '    If lb.Top < varHeight Then
    '        If Not jump Then
    '            lb.Top = lb.Top + gravity
    '            If gravity < gravityMaxAccel Then
    '                gravity = gravity + gravityAccel
    '            End If
    '        End If
    '        onGround = False
    '    Else
    '        gravity = gravityResetVal
    '        lb.Top = varHeight
    '        onGround = True
    '    End If

    '    If jump Then
    '        lb.Top = lb.Top - jumpSpeed
    '        If jumpSpeed > 0 Then
    '            jumpSpeed = jumpSpeed - jumpAccel
    '            gravity = gravityResetVal
    '        Else
    '            jump = False
    '            jumpSpeed = jumpSpeedResetVal
    '        End If
    '    End If

    Sub Update()

        If goUp Then
            xSpeed = xSpeed + 0.02
            straf()
        ElseIf goDown And xSpeed > 0 Then
            xSpeed = xSpeed - 0.03
        Else
            xSpeed = xSpeed - 0.01
        End If

        If xSpeed < 0 Then
            xSpeed = 0
        End If

        lb.Left = lb.Left + xSpeed

        'If goLeft Then
        '    ySpeed = ySpeed - 0.01
        'Else
        '    ySpeed = ySpeed - 0.01
        'End If

        'If ySpeed < 0 Then
        '    ySpeed = 0
        'End If

        'If goDown Then lb.top = lb.top + hSpeed

        'If goUp Then lb.top = lb.top - hSpeed

    End Sub

    Sub straf()
        If goRight Then
            lb.top = lb.top + 0.8
        End If
        If goLeft Then
            lb.top = lb.top - 0.8
        End If
    End Sub

    Sub dieToy()
        lb.left = lc1
        lb.top = lc2
        xSpeed = 0
        ySpeed = 0
    End Sub
End Class

